<?
require_once 'database.php';
?>